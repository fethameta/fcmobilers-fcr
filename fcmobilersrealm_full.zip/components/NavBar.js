import Link from "next/link";

export default function NavBar() {
  return (
    <nav style={{ padding: "1rem", background: "#1e1e1e" }}>
      <Link href="/">Home</Link> | <Link href="/top10/cam">Top 10</Link> |{" "}
      <Link href="/player-reviews">Reviews</Link> |{" "}
      <Link href="/tools/ovr-calculator">OVR Calculator</Link>
    </nav>
  );
}
