export default function handler(req, res) {
  const { password } = req.query;
  if (password === "230609") {
    res.status(200).json({ message: "Access granted to backend." });
  } else {
    res.status(403).json({ error: "Forbidden" });
  }
}
