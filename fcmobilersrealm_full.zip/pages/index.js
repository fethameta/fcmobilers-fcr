import NavBar from "../components/NavBar";

export default function Home() {
  return (
    <div>
      <NavBar />
      <h1>Welcome to FCMobilers Realm</h1>
      <p>Trusted FC Mobile Rankings, Reviews, and Tools</p>
    </div>
  );
}
