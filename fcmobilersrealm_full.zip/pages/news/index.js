export default function News() {
  return (
    <div>
      <h2>FC Mobile News & Leaks</h2>
      <p>Updated biweekly with card images and credible news.</p>
    </div>
  );
}
