export default function Reviews() {
  return (
    <div>
      <h2>Player Reviews</h2>
      <p>Unbiased FC Mobile reviews with ratings out of 10.</p>
    </div>
  );
}
