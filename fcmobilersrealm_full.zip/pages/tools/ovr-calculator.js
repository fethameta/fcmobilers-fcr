export default function OVRCalculator() {
  return (
    <div>
      <h2>OVR Calculator</h2>
      <p>Enter player ranks and training to calculate your team OVR.</p>
    </div>
  );
}
