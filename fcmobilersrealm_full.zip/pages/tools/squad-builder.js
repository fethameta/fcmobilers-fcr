export default function SquadBuilder() {
  return (
    <div>
      <h2>Squad Builder</h2>
      <p>Create and save your FC Mobile squads here.</p>
    </div>
  );
}
