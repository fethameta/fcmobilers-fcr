export default function Top10CAM() {
  return (
    <div>
      <h2>Top 10 CAMs in FC Mobile</h2>
      <ul>
        <li>1. Player A</li>
        <li>2. Player B</li>
      </ul>
    </div>
  );
}
